1024_full_features_day15.csv 所有点，三层全连接，1024->512->256
512_3l_full_features_day15.csv 所有点，三层全连接，512->256->64
512_3l_local_features_day15.csv 局部点，三层全连接，512->256->64
512_3l_local_monthless_features_day15.csv 局部点，无月份信息，三层全连接，512->256->64
512_full_features_day15.csv 所有点，两层全连接，512->256
512_local_features_day15.csv 局部点，两层全连接，512->256
512_local_monthless_features_day15.csv 局部点，无月份信息，两层全连接，512->256
256_full_features_day15.csv 所有点，一层全连接，256
256_local_features_day15.csv 局部点，一层全连接，256
256_local_monthless_features_day15.csv 局部点，无月份信息，一层全连接，256
MLP 全链接 一层 512
